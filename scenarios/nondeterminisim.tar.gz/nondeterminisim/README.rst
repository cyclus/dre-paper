See http://localhost:4050/posts/dre#Final_Thoughts
